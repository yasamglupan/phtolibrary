#imports sqlite and os
import sqlite3 
import os

#sets DATABASE_FILE to the dname of the database
DATABASE_FILE = "test.db"
column = ""

def cls():
    '''Clears the console'''
    os.system('cls' if os.name=='nt' else 'clear')

def show_cpus():
    '''Shows the database'''
    with sqlite3.connect(DATABASE_FILE) as connection:
        cursor = connection.cursor()
        #SQL query
        sql = "SELECT item.ID, item.name, item.price, Cpubrand.Brand_Name, \
        item.CPU_Mark, item.rank FROM item JOIN Cpubrand ON item.Brand_ID = Cpubrand.ID"
        #Executing sql
        cursor.execute(sql)
        #fetching results
        results = cursor.fetchall()
        #fromats all the information with gaps betwwen
        print(f"\n{'ID':<15}{'Name':<20}{'Price':<15}{'Brand':<15}{'CPU Mark':<15}{'Rank':<15}") #Formating
        for item in results:
            #Prints each collum in the database to create a table
            print(f"{item[0]:<15}{item[1]:<20}{item[2]:<15}{item[3]:<15}{item[4]:<15}{item[5]:<15}")
    

def add_item(item_name, item_description, item_brand, item_cpu_mark, item_rank):
    '''Adds an item to the list'''
    with sqlite3.connect(DATABASE_FILE) as connection:
        cursor = connection.cursor()
        #creating a sql query for add a item to the database
        sql = "INSERT INTO item(name,price,Brand_ID,CPU_Mark,rank) VALUES (?,?,?,?,?)"
        #Executing sql
        cursor.execute(sql,(item_name, item_description, item_brand, item_cpu_mark, item_rank))
        connection.commit()

def delete_item(remove_item):
    '''Deletes a CPU'''
    with sqlite3.connect(DATABASE_FILE) as connection:
        cursor = connection.cursor()
        #using id of the item that you want to delete to delete the item
        sql = f"DELETE FROM item WHERE item.ID = '{remove_item}'"
        #Executing sql
        cursor.execute(sql)
        connection.commit()

def update_item(item_id, new_information, collumn):
    '''Updates information of an item of an item'''
    with sqlite3.connect(DATABASE_FILE) as connection:
        cursor = connection.cursor()
        #using all the user input and putting it in a query to update a piece of information of the item
        sql = f"UPDATE item SET {collumn} = '{new_information}' WHERE ID = {item_id}"
        #Executing sql
        cursor.execute(sql)
        connection.commit()



# A universal sorting fuction that sorts that database to the users liking
def sort_items(item_name, order_type):
    '''Sorts items using user input'''
    with sqlite3.connect(DATABASE_FILE) as connection:
        cursor = connection.cursor()
        #first part of the query 
        sql = "SELECT ID, name, price, Brand_Name, CPU_Mark, rank FROM CPUInformation "
        #second part of the sql query using the information fro the user
        sql = sql + f"ORDER BY {item_name} {order_type}" 
        #Executing sql
        cursor.execute(sql)
        results = cursor.fetchall()
        #Formatting all the sorted information
        print(f"\n{'ID':<15}{'Name':<20}{'Price':<15}{'Brand':<15}{'CPU Mark':<15}{'Rank':<15}")
        for item in results:
            #Prints each collum in the database to create a table
            print(f"{item[0]:<15}{item[1]:<20}{item[2]:<15}{item[3]:<15}{item[4]:<15}{item[5]:<15}") 


def show_cpus_menu():
    
    print ("Showing Items")
    show_cpus()


def delete_menu():
    #First prints the whole database using the function show_cpus
    show_cpus()
    while True:
        try:
            while True:
                #asks for the id of the item you want to delete
                remove_item = int(input("What is the ID of this item?"))
                #checking that the id isn't negetive
                if remove_item >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    #runs the function using the information gathed above
    delete_item(remove_item)
    #clears the console
    cls()

def add_menu():
    #First prints the whole database using the function show_cpus
    show_cpus()
    #asks for the name of the new item
    new_item = input("What is the name of the new item?")
    while True:
        try:
            while True:
                #asks for the price
                new_item_price = float(input("What is the price of this item?"))
                #checking that the input isn't negetive
                if new_item_price >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    while True:
        #asks the user to chose between intel and ryzen for the brand
        new_item_brand = input("What is the brand of the cpu\n1. Intel\n2. Ryzen\n")
        #checking if the users put one of the two options
        if new_item_brand == "1" or new_item_brand == "2":
            #if they did it exits the loop
            break
        else:
            #if not it print then loops back and asks the question again
            print ("That is not a cpu brand!")
    while True:
        try:
            while True:
                #asks for the the CPU mark 
                new_item_cpu_mark = int(input("What is the CPU Mark of this item?"))
                #checking that the input isn't negetive
                if new_item_cpu_mark >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    while True:
        try:
            while True:
                #asks for the the rank of the CPU
                new_item_rank = int(input("What is the rank of this item?"))
                #checking that the input isn't negetive
                if new_item_rank >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    #takes all this information and passes it to the funtion add item to create the new item 
    add_item(new_item, new_item_price, new_item_brand, new_item_cpu_mark, new_item_rank)
    #Prints item added
    print ("Item added")
    #clears console
    cls()


def update_name_menu():
    #Shows all of the databse
    show_cpus()
    while True:
        try:
            while True:
                #asks for the id of the item you would like to update
                new_item_id = int(input("What is the ID of this item?"))
                #checking that the input isn't negetive
                if new_item_id >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    while True:
        try:
            #asks for the new name of the item
            new_name = input("What is the new name of this item?")
            break
        except:
            #if there is an error then it loops back
            print ("You stuffed up!")
    #passes all of the information gathered 
    update_item(new_item_id, new_name, "Name")
    #clears console
    cls()

def update_price_menu():
    #Shows the whole database
    show_cpus()
    while True:
        try:
            while True:
                #asks for the id of the item that you want to update
                new_item_id = int(input("What is the ID of this item?"))
                #checking that the input isn't negetive
                if new_item_id >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    while True:
        try:
            while True:
                #asks for the new price
                new_price = float(input("What is the new price of this item?"))
                #checking that the input isn't negetive
                if new_price >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    #passes all of the information gathered 
    update_item(new_item_id, new_price, "Price")
    #clears the console
    cls()

def update_cpu_mark_menu():
    #Shows the whole database
    show_cpus()
    while True:
        try:
            while True:
                #asks for the id of the item that you want to update
                new_item_id = int(input("What is the ID of this item?"))
                #checking that the input isn't negetive
                if new_item_id >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    while True:
        try:
            while True:
                #asks for the new CPU mark 
                new_cpu_mark = int(input("What is the new CPU Mark of this item?"))
                #checking that the input isn't negetive
                if new_cpu_mark >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    #passes all of the information gathered 
    update_item(new_item_id, new_cpu_mark, "CPU_Mark")
    #clears the console
    cls()


def update_rank_menu():
    #Shows the whole database
    show_cpus()
    while True:
        try:
            while True:
                #asks for the id of the item that you want to update
                new_item_id = int(input("What is the ID of this item?"))
                #checking that the input isn't negetive
                if new_item_id >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    while True:
        try:
            while True:
                new_rank = int(input("What is the new rank of this item?"))
                #checking that the input isn't negetive
                if new_rank >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    #passes all of the information gathered 
    update_item(new_item_id, new_rank, "rank")
    #clears console
    cls()

def update_brand_menu():
    #Shows the whole database
    show_cpus()
    while True:
        try:
            while True:
                new_item_id = int(input("What is the ID of this item?"))
                #checking that the input isn't negetive
                if new_item_id >= 0:
                    #if it isn't then leaves the loop
                    break
                else:
                    #if it is loops back and asks again
                    print ("That is a negitive!")
            break
        except:
            #if there are any errors it prints that is not a number then loops back
            print ("That is not a number")
    while True:
        #asks for the user to chose between intel and ryzen for the brand of the cpu
        new_brand = input("What is the brand of the cpu\n1. Intel\n2. Ryzen\n")
        #checking if the input is on of the options
        if new_brand == "1" or new_brand == "2":
            #if it is it leaves the loop
            break
        else:
            #if its not it prints a statement then loops back to the question
            print ("That is not a cpu brand!")
    #passes all of the information gathered 
    update_item(new_item_id, new_brand, "Brand_ID")
    #clears the console
    cls()

def order_type():
    while True:
        #asks the user how they world like to sort the iformation and gives them 2 options
        order = input("How would you like to sort the items\n1. Accending\n2. Descending\n")
        if order == "1":
            #if they chose Accending order is given the value ASC
            order = "ASC"
            break
        elif order == "2":
            #if they chose Descending order is given the value DESC
            order = "DESC"
            break
        else:
            #if none of these options were selected it loops back to the question
            print ("That is not a option!")
    #once order is found it returns it and ends the function.
    return order
