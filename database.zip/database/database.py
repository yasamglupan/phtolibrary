#importing sqlite and os
from bdb import Breakpoint
import sqlite3
import os
#Imports all the function from util.py
from util import cls, add_menu, delete_menu, update_name_menu, update_price_menu, update_cpu_mark_menu, update_brand_menu, show_cpus_menu, update_rank_menu, sort_items, order_type

    

while True:
    #prints out all of the options and waits for an input
    menu = input("1. Show items\n2. Add item\n3. Delete item\n4. Update information\n5. Sort items\n6. Quit\n")
    cls()
    if menu == "1":
        #calls the function that shows all the data 
        show_cpus_menu()

    elif menu == "2":
        password = input("What is the password?\n")
        if password == "fish":
            #calls the function that lets you add an item to the database
            add_menu()
        else:
            print ("Thats the wrong password!")

    elif menu == "3":
        password = input("What is the password?\n")
        if password == "fish":
            #calls the function that lets you delete an item from the database
            delete_menu()
        else:
            print ("Thats the wrong password!")

    elif menu == "4":
        password = input("What is the password?\n")
        if password == "fish":
            while True:
                update = input ("1. Update Price\n2. Update CPU Mark\n3. Update Rank\n4. Update Brand\n5. Update Name\n6. Go Back\n")
                cls()
                if update == "1":
                #calls the function that lets you update the price of a item in the database
                    update_price_menu()
                    break
                elif update == "2":
                #calls the function that lets you update the CPU mark of a item in the database
                    update_cpu_mark_menu()
                    break
                elif update == "3":
                #calls the function that lets you update the rank of a item in the database
                    update_rank_menu()
                    break
                elif update == "4":
                #calls the function that lets you update the rank of a item in the database
                    update_brand_menu()
                    break
                elif update == "5":
                #calls the function that lets you update the name of a item in the database
                    update_name_menu()
                    break
                elif update == "6":
                #Quits the update menu
                    break
                else:
                #if none of these worked it prints a stament and loops back to the start
                    print ("You stuffed up!")
        else:
              print ("Thats the wrong password!")
    elif menu == "5":
        while True:
            sort = input ("1. Sort By Name \n2. Sort By Price\n3. Sort By Brand\n4. Sort By CPU Mark\n5. Sort By Rank\n6. Go Back\n")
            cls()
            if sort == "1":
            #sets item name to the type of sort that the user wanted
                item_name = "name"
                break
            elif sort == "2":
            #sets item name to the type of sort that the user wanted
                item_name = "price"
                break
            elif sort == "3":
            #sets item name to the type of sort that the user wanted
                item_name = "Brand_Name"
                break
            elif sort == "4":
            #sets item name to the type of sort that the user wanted
                item_name = "CPU_Mark"
                break
            elif sort == "5":
            #sets item name to the type of sort that the user wanted
                item_name = "rank"
                break
            elif sort == "6":
            #Quits the sort menu
                break
            else:
            #if none of these worked it prints a stament and loops back to the start
                print ("You stuffed up!")
        if sort != "6":
            #Runs the order type function that gets the way the items will be order than sets that value to order by
            order_by = order_type()
            #This runs the function that sorts the itmes using the two values we got earlier
            sort_items(item_name, order_by)

    elif menu == "6":
        #Quits the program
        break

    else:
        #if none of these worked it prints a stament and loops back to the start
        print ("You stuffed up")

